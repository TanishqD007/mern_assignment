//import logo from './logo.svg';
//It is the main part of the react app . It calls the Diaplay function of display page.
import './App.css';
import DisplayFunction from './pages/display-page';


function App() {
  return (
    <div>
    <DisplayFunction/>
    </div>
  );
}

export default App;
