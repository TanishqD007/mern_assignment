//it contains the URL of database 
const URL = 'https://raw.githubusercontent.com/SauravRawat016/Api/main/api.json';
export default URL;